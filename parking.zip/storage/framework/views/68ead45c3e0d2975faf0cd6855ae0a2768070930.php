<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-layout','data' => ['title' => 'Register','isSidebarOpen' => 'true','isHeaderBlur' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Register','is-sidebar-open' => 'true','is-header-blur' => 'true']); ?>

    <main class="main-content w-full px-[var(--margin-x)] pb-8">

        <div class="min-h-screen flex items-center justify-center bg-gray-100">
            <div class="bg-white p-6 rounded shadow-md">
                <h1 class="text-2xl font-semibold mb-4">Registration Status</h1>
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>
                <?php if(session('success')): ?>
                    <div class="text-green-500 text-lg"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="text-red-500 text-lg">
                        <p>Vehicle Registration Error</p>
                        <p>Vehicle Registration for Permit at <?php echo e(session('property_code')); ?></p>
                        <p>We are sorry but your vehicle could not be registered.</p>
                        <p>Please visit <?php echo e(session('property_code')); ?> office for further information and resolve this
                            issue.</p>
                    </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- ... (later code) -->
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\parking\resources\views/registration.blade.php ENDPATH**/ ?>