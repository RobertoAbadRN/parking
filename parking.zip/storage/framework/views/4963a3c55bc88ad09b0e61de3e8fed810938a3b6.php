<main class="login-form">
    <div class="container">
      <div class="flex justify-center">
        <div class="w-8/12">
          <div class="card">
            <div class="card-header">Reset Password</div>
            <div class="card-body">
              <?php if(Session::has('message')): ?>
                <div class="alert alert-success" role="alert">
                  <?php echo e(Session::get('message')); ?>

                </div>
              <?php endif; ?>
              <form action="<?php echo e(route('forget.password.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                  <label for="email_address" class="block text-right">E-Mail Address</label>
                  <div class="col-md-6">
                    <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                    <?php if($errors->has('email')): ?>
                      <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="flex justify-center">
                  <button type="submit" class="btn btn-primary">Send Password Reset Link</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  

<?php /**PATH C:\xampp\htdocs\parking\resources\views/auth/forgetPassword.blade.php ENDPATH**/ ?>