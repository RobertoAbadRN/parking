<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.base-layout','data' => ['title' => 'Register','isSidebarOpen' => 'true','isHeaderBlur' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Register','is-sidebar-open' => 'true','is-header-blur' => 'true']); ?>
    <main class="main-content w-full px-[var(--margin-x)] pb-8">
        <div class="container mx-auto">
            <?php if(session('successMessage')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative"
                    role="alert">
                    <span class="block sm:inline"><?php echo e(session('successMessage')); ?></span>
                </div>
            <?php endif; ?>

            <h2 class="text-2xl font-semibold mb-4">Visitor Pass Registration Completed</h2>
            <div class="overflow-x-auto">
                <div class="flex overflow-x-auto">
                    <table class="table-auto w-full sm:w-5/6 md:w-4/5 bg-white border rounded shadow-sm text-sm sm:text-base">
                           <tbody>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">VP Code</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->vp_code); ?></td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Property Code</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->property_code); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Visitor Name</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->visitor_name); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Visitor Phone</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->visitor_phone); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">License Plate</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->license_plate); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Year</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->year); ?></td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Make</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->make); ?></td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Color</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->color); ?></td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Model</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->model); ?></td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Vehicle Type</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->vehicle_type); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="py-2 px-4 border-b border-gray-200 font-semibold">Valid From</td>
                                <td class="py-2 px-4 border-b border-gray-200"><?php echo e($latestVisitorPass->valid_from); ?>

                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" class="py-4 px-4 text-sm text-gray-500">
                                    The VP code above WILL ONLY BE SHOWN ONCE. <br>
                                    IT MUST BE VISIBLE in the windshield of your vehicle on the driver's side. <br>
                                    If this code is not visible, your vehicle may be...<br>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="pt-5">
                    <button id="printButton" class="btn bg-primary  text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90">
                        Print
                    </button>
                </div>                
            </div>


            <script>
                document.getElementById('printButton').addEventListener('click', function () {
                    // Ocultar el botón de impresión antes de imprimir
                    this.style.display = 'none';
            
                    // Lanzar el diálogo de impresión
                    window.print();
            
                    // Restaurar el botón de impresión después de imprimir (opcional)
                    this.style.display = 'block';
                });
            </script>
            
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\parking\resources\views/errorregister.blade.php ENDPATH**/ ?>