<p>Hola <?php echo e($user->name); ?>,</p>
<p>Por favor, haz clic en el siguiente enlace para revisar y aceptar nuestros términos y condiciones:</p>
<a href="<?php echo e($link); ?>">Leer Términos y Condiciones</a>
<?php /**PATH C:\xampp\htdocs\parking\resources\views/emails/sign-agreement.blade.php ENDPATH**/ ?>