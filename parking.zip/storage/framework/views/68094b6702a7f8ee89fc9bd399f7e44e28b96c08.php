<!DOCTYPE html>
<html>
<head>
    <title>Remolcar el Auto</title>
</head>
<body>
    <h1>Favor de remolcar el auto</h1>
    <p>Se ha detectado un permiso suspendido para el vehículo con placa: <?php echo e($licensePlate); ?>. Por favor, tome las medidas necesarias.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\parking\resources\views/emails/remolcar_auto.blade.php ENDPATH**/ ?>