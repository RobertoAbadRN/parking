export { charts } from "./apexchartDemo";
export { tomSelect } from "./tomselectDemo";

export * as tables from "./tablesDemo";
export * as formValidation from "./formValidationDemo";

export { default as initCreditCard } from "./initCreditCard";
