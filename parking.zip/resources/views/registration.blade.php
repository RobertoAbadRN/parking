<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Tus metadatos, enlaces a estilos, etc. -->
</head>
<body>
   <!-- ... (código anterior) -->

<div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-6 rounded shadow-md">
        <h1 class="text-2xl font-semibold mb-4">Registration Status</h1>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>
        auto registado con exito 
    </div>
</div>

<!-- ... (código posterior) -->

</body>
</html>

