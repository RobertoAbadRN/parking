<p>Hola {{ $user->name }},</p>
<p>Por favor, haz clic en el siguiente enlace para revisar y aceptar nuestros términos y condiciones:</p>
<a href="{{ $link }}">Leer Términos y Condiciones</a>
