<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Resident Suspension</title>
</head>
<body>
    <h1>Resident Suspension</h1>
    
    <p>Dear {{ $resident->name }},</p>
    
    <p>Your resident status has been suspended. Please contact our office for more information.</p>
    
    <p>Thank you.</p>
</body>
</html>
