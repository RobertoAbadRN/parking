<!DOCTYPE html>
<html>
<head>
    <title>Activate Resident</title>
</head>
<body>
    <h1>Activate Resident</h1>
    <p>Your account has been successfully activated.</p>
</body>
</html>
