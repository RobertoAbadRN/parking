<h1>Welcome to YourWebsite!</h1>

<p>Thank you for registering an account with us.</p>

<p>Here are your registration details:</p>

<p>
    <strong>Username:</strong> {{ $user->user }} <br>
    <strong>Email:</strong> {{ $user->email }} <br>
    <strong>Password:</strong> {{ $plainPassword }}
    <strong>link:</strong>https://amartineztowingop.com/login<br>
</p>

<p>If you have any questions or need further assistance, feel free to contact us.</p>

<p>Regards,</p>
<p>YourWebsite Team</p>
