<x-base-layout title="Login">
    <main class="grid w-full grow grid-cols-1 lg:grid-cols-2 place-items-center">
        <div class="min-h-screen flex flex-col items-center justify-center">
            <h1 class="text-4xl font-bold text-gray-800 mb-4">¡En mantenimiento!</h1>
            <p class="text-lg text-gray-600">Estamos trabajando en el sitio en este momento. Por favor, vuelve más tarde.</p>
        </div>

    </main>


</x-base-layout>
