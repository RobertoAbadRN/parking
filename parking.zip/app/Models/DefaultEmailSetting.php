<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DefaultEmailSetting extends Model
{
    protected $table = 'default_email_settings'; // Nombre de la tabla en la base de datos

    // Resto de la definición del modelo
}
