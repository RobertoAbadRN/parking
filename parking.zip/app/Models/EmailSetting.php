<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmailSetting extends Model
{
    protected $table = 'emails_settings'; // Nombre de la tabla en la base de datos
}


